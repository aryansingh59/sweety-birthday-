# Happy Birthday Sweety 💗

Ek romantic birthday website (HTML + CSS + JavaScript).

## Files
- `index.html` : page ka structure
- `style.css` : saara design
- `script.js` : saari animations aur features. **Sabse upar `CONFIG` mein photos ke captions, love story, chat, shayari aur gifts badal sakte ho**
- `voice.mp3` : voice sandesh (apni awaaz record karke isi naam se badal do)
- `voice-data.js` : voice ka backup, ise chhedna nahi hai
- `photos/` : apni photos `1.jpg` se `6.jpg` naam se yahan rakho

## GitHub Pages par live kaise karein
1. GitHub par naya repository banao (jaise `for-sweety`).
2. **Add file > Upload files** se is folder ki saari files aur `photos` folder daalo, phir **Commit changes**.
3. **Settings > Pages** mein jao. **Source** mein `Deploy from a branch`, branch `main` aur folder `/ (root)` chuno, phir **Save**.
4. 1 se 2 minute baad upar ek link aayega: `https://TUMHARA-USERNAME.github.io/for-sweety/`. Wahi link Sweety ko bhejo.

Dhyan rakho: free account mein GitHub Pages ki site public hoti hai, link jaanne wala koi bhi dekh sakta hai. Isliye repo ka naam aisa rakho jo aasani se guess na ho.
