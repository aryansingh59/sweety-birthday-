Yahan apni photos rakho: 1.jpg, 2.jpg, 3.jpg, 4.jpg, 5.jpg, 6.jpg (portrait photos best lagti hain).
Photo na ho to site apni romantic illustrations dikhati hai.
Captions script.js ke upar CONFIG mein badal sakte ho.
